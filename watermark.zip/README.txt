To enable watermark on the fly - please copy this files to /photos2 directory of installed EWC CMS
watermark.png is your watermark
Please edit watermark.png for custom watermark