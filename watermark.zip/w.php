<?php

/*
htaccess content must have
RewriteEngine on
RewriteRule ^([^tn_].*\.[jJ].*)$ /photos2/w.php?i=$1
*/

$basedir="./";
$watermarkimage="watermark.png";

$file=basename($_GET['i']);

$image = $basedir."/".$file;
$watermark = $basedir."/".$watermarkimage;
$im = imagecreatefrompng($watermark);

$ext = substr($image, -3);

if (strtolower($ext) == "gif") {
if (!$im2 = imagecreatefromgif($image)) {
echo "Error opening $image!"; exit;
}
} else if(strtolower($ext) == "jpg") {
if (!$im2 = imagecreatefromjpeg($image)) {
echo "Error opening $image!"; exit;
}
} else if(strtolower($ext) == "png") {
if (!$im2 = imagecreatefrompng($image)) {
echo "Error opening $image!"; exit;
}
} else {
die;
}

imageAlphaBlending($im2,1);
imageAlphaBlending($im,1);
imagesavealpha($im2,1);
imagesavealpha($im,1);

//imagefilledrectangle($im2, 0  , (imagesy($im2))-(imagesy($im)) , imagesx($im2)  , imagesy($im2) , imagecolorallocatealpha($im2, 0, 0, 0, 100) );
imagecopy($im2, $im, (imagesx($im2)-(imagesx($im))), (imagesy($im2))-(imagesy($im)), 0, 0, imagesx($im), imagesy($im));

$last_modified = gmdate('D, d M Y H:i:s T', filemtime ($image));

header("Last-Modified: $last_modified");
if (strtolower($ext) == "gif") {
header("Content-Type: image/gif");
imagegif($im2);
} else if(strtolower($ext) == "jpg") {
header("Content-Type: image/jpeg");
imagejpeg($im2,NULL,99);
} else if(strtolower($ext) == "png") {
header("Content-Type: image/png");
imagepng($im2);
}

imagedestroy($im);
imagedestroy($im2);

?>
